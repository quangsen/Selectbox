import React, {
    Component
} from 'react';

export default class Input extends Component {
    onfocus = () => {
        this.props.ActiveFocus();
    }

    onChange = (event) => {
        this.props.onChange(event.target.value)
    }

    render() { 
        let {valueinput} = this.props;
        return (
            <div className='input'>
                <input 
                    value={valueinput} 
                    onFocus={this.onfocus} 
                    className='input'
                    placeholder={this.props.valueinput}
                    id='input'
                />
            </div>
        );
    }
}